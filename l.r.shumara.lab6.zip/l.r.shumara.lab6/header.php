<div class="header">
    <img src="photos/header.png" alt="" class="hauptfoto">
</div>

<div class="dotsandsquares">
    <img src="photos/dotsandsquares.png" alt="" class="hauptpunkte">
</div>

<div class="upperButtons">
    <div class="navi" style="width:7.1%;">
        <div class="innerNavi">
            Navigation
        </div>
    </div>
    <div class="hex" style="width:61.7%;">
        <div class="innerHex">
            <img src="photos/hexagons.png" alt="">
        </div>
    </div>
    <div class="hosting">
        <div class="innerHosting">
            Hosting
        </div>
    </div>
    <div class="services">
        <div class="innerServices">
            Services
        </div>
    </div>
    <div class="support">
        <div class="innerSupport">
            Support
        </div>
    </div>
    <div class="contact">
        <div class="innerContact">
            Contact
        </div>
    </div>
    <div class="triangle" style="width:2.05%">
        <div class="innerTriangle">
            <img src="photos/triangle.png" alt="">
        </div>
    </div>
</div>

<div class="dots">
    <img src="photos/dots.png" alt="" class="punkte">
</div>