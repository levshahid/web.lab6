<div class="squares">
    <img src="photos/squares.png" alt="" class="end">
</div>

<div class="footer">
    © Copyright 2002 WEBHOSTING Corporation. All Rights Reserved.
</div>

<div id="funf">
    
</div>